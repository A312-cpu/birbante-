package com.birbante.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import org.json.JSONArray
import org.maplibre.android.MapLibre
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.annotations.MarkerOptions
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var map: MapLibreMap
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private var lat: Double? = null; private var lon: Double? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted[Manifest.permission.ACCESS_FINE_LOCATION] == true || granted[Manifest.permission.ACCESS_COARSE_LOCATION] == true) locate() else status.text = "Permesso posizione negato."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)
        mapView=findViewById(R.id.mapView); mapView.onCreate(savedInstanceState)
        status=findViewById(R.id.status); results=findViewById(R.id.results)
        mapView.getMapAsync { m -> map=m; m.setStyle("https://demotiles.maplibre.org/style.json") { m.cameraPosition = org.maplibre.android.camera.CameraPosition.Builder().target(LatLng(45.4642,9.19)).zoom(11.5).build() } }
        findViewById<Button>(R.id.locationButton).setOnClickListener { requestLocation() }
        findViewById<Button>(R.id.searchButton).setOnClickListener { search() }
    }

    private fun requestLocation() {
        val fine=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        val coarse=ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
        if(fine||coarse) locate() else permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    private fun locate() {
        status.text="Rilevamento posizione…"
        LocationServices.getFusedLocationProviderClient(this).getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,CancellationTokenSource().token)
            .addOnSuccessListener { l -> if(l!=null) showLocation(l) else status.text="Posizione non disponibile. Controlla GPS e servizi di localizzazione." }
            .addOnFailureListener { status.text="Errore GPS: ${it.message ?: "sconosciuto"}" }
    }
    private fun showLocation(l: Location) {
        lat=l.latitude; lon=l.longitude
        val p=LatLng(l.latitude,l.longitude); map.clear(); map.addMarker(MarkerOptions().position(p).title("Sei qui")); map.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(p,15.5))
        status.text="Posizione reale: %.5f, %.5f · precisione ~%d m".format(l.latitude,l.longitude,l.accuracy.toInt())
    }
    private fun search() {
        val la=lat; val lo=lon; if(la==null||lo==null){status.text="Prima premi POSIZIONE e concedi il permesso.";return}
        val q=findViewById<EditText>(R.id.searchInput).text.toString().trim().ifEmpty{"bar"}
        status.text="Cerco $q vicino alla tua posizione…"; results.removeAllViews()
        executor.execute {
            try {
                val d=.035; val bbox="${lo-d},${la+d},${lo+d},${la-d}"
                val url="https://nominatim.openstreetmap.org/search?format=jsonv2&limit=15&addressdetails=1&q=${URLEncoder.encode(q,"UTF-8")}&viewbox=$bbox&bounded=1"
                val c=URL(url).openConnection() as HttpURLConnection; c.requestMethod="GET"; c.setRequestProperty("User-Agent","Birbante/0.4 Android demo"); c.connectTimeout=10000; c.readTimeout=10000
                val body=c.inputStream.bufferedReader().use{it.readText()}; val arr=JSONArray(body)
                val list=(0 until arr.length()).map{arr.getJSONObject(it)}.sortedBy{distance(la,lo,it.getDouble("lat"),it.getDouble("lon"))}
                runOnUiThread { map.clear(); map.addMarker(MarkerOptions().position(LatLng(la,lo)).title("Sei qui")); list.forEach { x -> addResult(x,la,lo) }; status.text="Trovati ${list.size} risultati, ordinati per distanza." }
            } catch(e:Exception){runOnUiThread{status.text="Ricerca non riuscita: ${e.message ?: "errore di rete"}"}}
        }
    }
    private fun addResult(x: org.json.JSONObject, la:Double,lo:Double) {
        val r=LinearLayout(this); r.orientation=LinearLayout.VERTICAL; r.setPadding(10,8,10,8); r.setBackgroundColor(Color.rgb(34,37,45))
        val name=x.optString("name").ifEmpty{x.optString("display_name").substringBefore(",")}; val d=distance(la,lo,x.getDouble("lat"),x.getDouble("lon"))
        val t=TextView(this); t.text="${name}\n${if(d<1) "%.0f m".format(d*1000) else "%.1f km".format(d)} · ${x.optString("type","luogo")}\n${x.optString("display_name")}"; t.setTextColor(Color.WHITE); r.addView(t)
        val b=Button(this); b.text="📌 Mostra sulla mappa"; b.setOnClickListener{val p=LatLng(x.getDouble("lat"),x.getDouble("lon")); map.addMarker(MarkerOptions().position(p).title(name)); map.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(p,17.0))}; r.addView(b)
        results.addView(r)
    }
    private fun distance(a:Double,b:Double,c:Double,d:Double):Double { val R=6371.0; val p=PI/180; val x=sin((c-a)*p/2).pow(2)+cos(a*p)*cos(c*p)*sin((d-b)*p/2).pow(2); return R*2*atan2(sqrt(x),sqrt(1-x)) }
    override fun onStart(){super.onStart();mapView.onStart()}; override fun onResume(){super.onResume();mapView.onResume()}; override fun onPause(){mapView.onPause();super.onPause()}; override fun onStop(){mapView.onStop();super.onStop()}; override fun onDestroy(){executor.shutdownNow();mapView.onDestroy();super.onDestroy()}; override fun onLowMemory(){super.onLowMemory();mapView.onLowMemory()}
}
